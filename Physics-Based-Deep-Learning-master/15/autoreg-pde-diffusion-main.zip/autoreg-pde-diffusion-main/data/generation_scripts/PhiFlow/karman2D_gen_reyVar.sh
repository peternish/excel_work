scriptPath="demos/karman2D.py"

# python $scriptPath OUTDIR  RES_X RES_Y DT  STEPS WARMUP  CYL_SIZE VEL VISC  REYNOLDS_START REYNOLDS_END
python $scriptPath 256_reyVar  256 128 0.05  800 20  0.6 0.5 -  200 900
