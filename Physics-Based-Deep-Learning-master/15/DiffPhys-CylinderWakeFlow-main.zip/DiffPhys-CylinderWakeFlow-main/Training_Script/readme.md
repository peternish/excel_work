The script allows for the training of the DPNN model. 

Pre-requisite: Installed libraries and ground truth dataset
