
By default, the simulation data for the data generation and training runs  will end up in this directory.

