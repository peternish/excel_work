This directory is for test run data from double precision executables; treated like the one for single precision data otherwise.
