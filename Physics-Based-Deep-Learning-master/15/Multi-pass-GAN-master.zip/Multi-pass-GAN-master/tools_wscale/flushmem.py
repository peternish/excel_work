import numpy as np

t = np.zeros((1024,1024,1024,16))
t += 1.0
print(t.shape)
exit(1)
