by default, the simulation data for the examples will end up in this directory
