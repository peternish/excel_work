# phi scenes are scenes and tests that use a large simulation, often with GUI
