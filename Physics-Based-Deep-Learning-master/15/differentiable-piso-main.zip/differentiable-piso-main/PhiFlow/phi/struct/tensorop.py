# Alias for phi.backend.tensorop for compatibility
from ..backend.tensorop import *