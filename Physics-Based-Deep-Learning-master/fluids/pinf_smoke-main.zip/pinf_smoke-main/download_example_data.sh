cd data
wget https://rachelcmy.github.io/pinf_smoke/data/pinf_data.zip
unzip pinf_data.zip
cd ..
